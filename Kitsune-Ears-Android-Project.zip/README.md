# Kitsune Ears — S999 MKamuy Voice Monitor (prototype)

Standalone Android app. Does **not** modify the existing S999 launcher.

## Version 0.1
- Type comma-separated keywords and tap SAVE KEYWORDS.
- Tap START LISTENING while app is visible and grant microphone permission.
- Android speech-recognition service attempts repeated listening sessions; when a configured phrase is recognised, Kitsune Ears shows a notification.
- STOP LISTENING stops the service.
- TEST NOTIFICATION verifies the notification path (Android 13+ requires notification permission).
- All saved keywords are in local app preferences. No cloud AI integration, recording archive or transmission to ChatGPT is included.

## Limitations
- Android SpeechRecognizer is **not designed for uninterrupted continuous recognition**. Restarting it may leave gaps, repeated starts may be throttled, and the S999 firmware may suspend the service when the screen is off.
- Some Android speech recognizers use online speech processing. If you need strictly on-device processing, integrate a dedicated on-device wake-word/speech engine later.
- Microphone permission, Android's always-visible foreground indicator, and user control are intentional. Use only where recording is lawful and people are appropriately informed.
- Do not store secrets in GitHub or the Android project.

## GitHub
Upload `Kitsune-Ears-Android-Project.zip` to the repository root and `.github/workflows/main.yml` to the indicated path. The action will compile a debug APK that can be downloaded from its run's Artifacts section.
