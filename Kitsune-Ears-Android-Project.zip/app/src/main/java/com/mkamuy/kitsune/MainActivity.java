package com.mkamuy.kitsune;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText keywords;
    private static final int REQ_PERMISSIONS = 101;
    private static final int REQ_TEST_NOTIFICATION = 102;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ListenService.ensureChannels(this);
        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        scroller.setBackgroundColor(Color.rgb(15,17,19));
        LinearLayout root = new LinearLayout(this);
        root.setPadding(28,20,28,20);
        root.setOrientation(LinearLayout.VERTICAL);
        scroller.addView(root);
        label(root,"狐の耳 / KITSUNE EARS",21,Color.WHITE);
        label(root,"MKAMUY  //  KEYWORD MONITOR",12,Color.LTGRAY);
        label(root,"Keywords or phrases (separate with commas)",14,Color.WHITE);
        keywords = new EditText(this);
        keywords.setSingleLine(false);
        keywords.setMinLines(2);
        keywords.setTextColor(Color.WHITE);
        keywords.setHintTextColor(Color.LTGRAY);
        keywords.setHint("e.g. kitsune, traffic, reminder");
        keywords.setText(getSharedPreferences("kitsune",MODE_PRIVATE).getString("keywords","kitsune, traffic, reminder"));
        root.addView(keywords);
        button(root,"SAVE KEYWORDS",v -> save());
        button(root,"START LISTENING",v -> {
            save();
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED ||
                    (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)) {
                if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS},REQ_PERMISSIONS);
                else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},REQ_PERMISSIONS);
                return;
            }
            startMonitor();
        });
        button(root,"STOP LISTENING",v -> {
            Intent intent=new Intent(this,ListenService.class);
            intent.setAction(ListenService.ACTION_STOP);
            startService(intent);
            Toast.makeText(this,"Listening stopped",Toast.LENGTH_SHORT).show();
        });
        button(root,"TEST NOTIFICATION",v -> {
            if (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_TEST_NOTIFICATION);
            } else {
                testNotification();
            }
        });
        label(root,"Listening uses Android speech recognition. Some devices/services require internet. The service may pause or stop due to system restrictions. A persistent notification shows when listening is active.",12,Color.LTGRAY);
        label(root,"V0.1 • Local keyword notifications only • No OpenAI connection or recording upload",12,Color.GRAY);
        setContentView(scroller);
    }
    private void startMonitor(){
        Intent i=new Intent(this,ListenService.class);
        i.setAction(ListenService.ACTION_START);
        try { if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }
        catch(Exception e){ Toast.makeText(this,"Could not start microphone: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] perms,int[] results){
        super.onRequestPermissionsResult(requestCode,perms,results);
        if(requestCode==REQ_PERMISSIONS && checkSelfPermission(Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED) startMonitor();
        if(requestCode==REQ_TEST_NOTIFICATION && (Build.VERSION.SDK_INT<33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)) testNotification();
    }
    private void testNotification(){
        ListenService.sendAlert(this,"TEST: Kitsune Ears","Your test alert is working.");
        Toast.makeText(this,"Test notification requested",Toast.LENGTH_SHORT).show();
    }
    private void save(){
        getSharedPreferences("kitsune",MODE_PRIVATE).edit().putString("keywords",keywords.getText().toString().trim()).apply();
        Toast.makeText(this,"Keywords saved on device",Toast.LENGTH_SHORT).show();
    }
    private void label(LinearLayout root,String t,int sp,int color){
        TextView v=new TextView(this); v.setText(t);v.setTextSize(sp);v.setTextColor(color);
        v.setPadding(0,7,0,7); root.addView(v);
    }
    private void button(LinearLayout root,String title,View.OnClickListener action){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setOnClickListener(action);root.addView(b);
    }
}
