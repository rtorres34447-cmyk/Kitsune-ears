package com.mkamuy.kitsune;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import java.util.ArrayList;
import java.util.Locale;

public class ListenService extends Service {
    public static final String ACTION_START="com.mkamuy.kitsune.START";
    public static final String ACTION_STOP="com.mkamuy.kitsune.STOP";
    private static final String LISTEN_CH="kitsune_listening", ALERT_CH="kitsune_alerts";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SpeechRecognizer recognizer;
    private boolean active=false;
    private boolean busy=false;
    private long lastAlert=0;
    private final Runnable restart = this::listen;

    public static void ensureChannels(Context ctx){
        NotificationManager nm=(NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26){
            nm.createNotificationChannel(new NotificationChannel(LISTEN_CH,"Kitsune listening",NotificationManager.IMPORTANCE_LOW));
            nm.createNotificationChannel(new NotificationChannel(ALERT_CH,"Kitsune keyword alerts",NotificationManager.IMPORTANCE_HIGH));
        }
    }
    @Override public void onCreate(){super.onCreate();ensureChannels(this);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && ACTION_STOP.equals(intent.getAction())){stopSelf();return START_NOT_STICKY;}
        if(!active){
            active=true;
            Notification n=new Notification.Builder(this,LISTEN_CH)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentTitle("Kitsune Ears listening")
                .setContentText("Keyword monitoring is active • Tap to open")
                .setOngoing(true)
                .setContentIntent(PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT))
                .build();
            try{startForeground(21,n);}catch(RuntimeException ex){active=false;stopSelf();return START_NOT_STICKY;}
            if(!SpeechRecognizer.isRecognitionAvailable(this)){
                sendAlert(this,"Kitsune Ears","No compatible Android speech recognizer installed.");
                stopSelf();return START_NOT_STICKY;
            }
            recognizer=SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener(){
                @Override public void onReadyForSpeech(Bundle b){}
                @Override public void onBeginningOfSpeech(){}
                @Override public void onRmsChanged(float rms){}
                @Override public void onBufferReceived(byte[] data){}
                @Override public void onEndOfSpeech(){}
                @Override public void onError(int code){busy=false;schedule(1500);}
                @Override public void onResults(Bundle b){busy=false;scan(b);schedule(800);}
                @Override public void onPartialResults(Bundle b){scan(b);}
                @Override public void onEvent(int type,Bundle b){}
            });
            listen();
        }
        return START_NOT_STICKY;
    }
    private void scan(Bundle b){
        if(b==null)return;
        ArrayList<String> guesses=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if(guesses==null||guesses.isEmpty())return;
        String spoken=guesses.get(0).toLowerCase(Locale.ROOT);
        String raw=getSharedPreferences("kitsune",MODE_PRIVATE).getString("keywords","");
        if(raw.trim().isEmpty())return;
        for(String part:raw.split(",")){
            String phrase=part.trim().toLowerCase(Locale.ROOT);
            if(!phrase.isEmpty() && spoken.contains(phrase)){
                long now=android.os.SystemClock.elapsedRealtime();
                if(now-lastAlert>45000){lastAlert=now;sendAlert(this,"Kitsune heard: "+phrase,"Keyword detected. Open Kitsune Ears to review settings.");}
                break;
            }
        }
    }
    private void schedule(long ms){if(active){handler.removeCallbacks(restart);handler.postDelayed(restart,ms);}}
    private void listen(){
        if(!active||busy||recognizer==null)return;
        busy=true;
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault().toLanguageTag());
        try{recognizer.startListening(i);}catch(Exception e){busy=false;schedule(3000);}
    }
    public static void sendAlert(Context ctx,String title,String body){
        ensureChannels(ctx);
        Notification.Builder b=new Notification.Builder(ctx,ALERT_CH)
             .setSmallIcon(android.R.drawable.ic_dialog_info)
             .setContentTitle(title).setContentText(body).setAutoCancel(true);
        ((NotificationManager)ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%1000000),b.build());
    }
    @Override public void onDestroy(){
        active=false;handler.removeCallbacksAndMessages(null);
        if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
